# Ezblock Studio for Raspberry Pi

- [Ezblock Studio for Raspberry Pi](#ezblock-studio-for-raspberry-pi)
  - [Introduction](#introduction)
  - [Installation Guide](#installation-guide)
  - [Uninstallation Guide](#uninstallation-guide)

## Introduction

This is Ezblock Studio for Raspberry Pi, build with Qt5

## Installation Guide

You will need qt runtime for Ezblock Studio

```bash
wget https://sunfounder.s3.us-east-1.amazonaws.com/others/qt5pi.zip
uzip qt5pi.zip
sudo cp qt5pi /usr/local/qt5pi
```

Install Ezblock Studio

```bash
uzip ezblock-studio-for-raspi-v1.0.0.zip
cd ezblock-studio
chmod +x install
sudo ./install
```

## Uninstallation Guide

If somehow you don't want Ezblock Studio anymore, here's how you uninstall it.

```bash
cd ezblock-studio
chmod +x uninstall
sudo ./uninstall
```
