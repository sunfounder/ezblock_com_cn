import os
import sys
import time

# log_file = open('/opt/ezblock/log','a+')
def log(msg:str=None,level='Upgrade',end='\n',flush=False,timestamp=True):
    if timestamp == True:
        _time = time.strftime("%y/%m/%d %H:%M:%S", time.localtime())
        ct = time.time()
        _msecs = '%03d '%((ct - int(ct)) * 1000)
        # print('%s,%s[%s] %s'%(_time,_msecs,level,msg), end=end, flush=flush, file=log_file)
        print('%s,%s[%s] %s'%(_time,_msecs,level,msg), end=end, flush=flush, file=sys.stdout)
    else:
        # print('%s'%msg, end=end, flush=flush, file=log_file)
        print('%s'%msg, end=end, flush=flush, file=sys.stdout) 

def run_command(cmd):
    import subprocess
    p = subprocess.Popen(
        cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    result = p.stdout.read().decode('utf-8')
    status = p.poll()
    return status, result

errors = []
def do(msg="", cmd=""):
    log(" - %s... " % (msg), end='', flush=True)
    status, result = run_command(cmd)
    if status == 0 or status == None or result == "":
        log(msg='Done',timestamp=False)
    else:   
        log(msg='\033[1;35mError\033[0m',timestamp=False)
        errors.append("%s error:\n  Status:%s\n  Error:%s" %
                      (msg, status, result))


def update():
    log('Upgrading to version 1.0.3')
    
    do(msg='copy file:ezb-pi' ,
        cmd='sudo cp -rf /opt/ezblock/1.0.3/ezb-pi/* /home/pi/ezb-pi/ '
        +'&& sudo cp -rf /opt/ezblock/1.0.3/ezb-pi/workspace/*  /opt/ezblock/')

    do(msg='copy file:workspace',
        cmd='sudo cp -rf /opt/ezblock/1.0.3/ezb-pi/workspace/*  /opt/ezblock/')

    do(msg='copy file:bin',
        cmd='sudo cp -rf /opt/ezblock/1.0.3/ezb-pi/bin/* /usr/bin/ ')


    os.chdir("/home/pi/ezb-pi/ezblock/")
    do(msg='clear the cache',
        cmd='sudo rm  -rf build/ dist/ ezblock.egg-info/')
    os.popen("sudo rm -rf /home/pi//ezb-pi/workspace/log")

    do(msg='uninstall ezblock ',
        cmd='sudo pip3 uninstall ezblock -y')

    do(msg='install lsof ',
        cmd='sudo apt install lsof')
    
    do(msg='install ezblock',
        cmd='sudo python3 setup.py install')

    # do(msg='reboot ',
    #     cmd='sudo service ezblock stop && sudo reboot')


    if len(errors) == 0:
        log("Finished.")
        return True
    else:
        log('\n\n\033[1;35mError happened in install process:\033[0m')
        for error in errors:
            log(error)
        log("Try to fix it yourself, or contact service@sunfounder.com with this message")
        return False 


if __name__ == "__main__":
    try:
       update() 
    except KeyboardInterrupt:
        log("Canceled.")

