import os
import sys
import time

# log_file = open('/opt/ezblock/log','a+')
def log(msg:str=None,level='Upgrade',end='\n',flush=False,timestamp=True):
    if timestamp == True:
        _time = time.strftime("%y/%m/%d %H:%M:%S", time.localtime())
        ct = time.time()
        _msecs = '%03d '%((ct - int(ct)) * 1000)
        # print('%s,%s[%s] %s'%(_time,_msecs,level,msg), end=end, flush=flush, file=log_file)
        print('%s,%s[%s] %s'%(_time,_msecs,level,msg), end=end, flush=flush, file=sys.stdout)
    else:
        # print('%s'%msg, end=end, flush=flush, file=log_file)
        print('%s'%msg, end=end, flush=flush, file=sys.stdout) 

def run_command(cmd):
    import subprocess
    p = subprocess.Popen(
        cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    result = p.stdout.read().decode('utf-8')
    status = p.poll()
    return status, result

errors = []
def do(msg="", cmd=""):
    log(" - %s... " % (msg), end='', flush=True)
    status, result = run_command(cmd)
    if status == 0 or status == None or result == "":
        log(msg='Done',timestamp=False)
    else:   
        log(msg='\033[1;35mError\033[0m',timestamp=False)
        errors.append("%s error:\n  Status:%s\n  Error:%s" %
                      (msg, status, result))


def update():
    log('Upgrading to version 1.2.1 ...')
    
    os.chdir("/home/pi/ezb-pi/")
    do(msg='git remote set-url origin',
        cmd='git remote set-url origin https://github.com/ezblockcode/ezb-pi.git')
   
    # do(msg="chown pi:pi",
    #     cmd="sudo chown -R pi:pi ./")

    do(msg='git fetch',
        cmd='git fetch')

    do(msg='git checkout -f 1.2.1',
        cmd='git checkout -f 1.2.1')

    do(msg="install pico2wave",
    cmd='wget http://ftp.us.debian.org/debian/pool/non-free/s/svox/libttspico0_1.0+git20130326-9_armhf.deb'
        +' && wget http://ftp.us.debian.org/debian/pool/non-free/s/svox/libttspico-utils_1.0+git20130326-9_armhf.deb'
        +' && sudo apt-get install -f ./libttspico0_1.0+git20130326-9_armhf.deb ./libttspico-utils_1.0+git20130326-9_armhf.deb -y')
        
    do(msg='install 1.2.1',
        cmd='sudo python3 install.py --no-dep')

    if len(errors) == 0:
        log("Finished.")
        sys.exit(0) # success
    else:
        log('\n\n\033[1;35mError happened in install process:\033[0m')
        for error in errors:
            log(error)
        log("Try to fix it yourself, or contact service@sunfounder.com with this message")
        sys.exit(1) # failed


if __name__ == "__main__":
    try:
       update() 
    except KeyboardInterrupt:
        log("Canceled.")

