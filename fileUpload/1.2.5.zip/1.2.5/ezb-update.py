import os
import sys
import time

VERSION = "1.2.5"

# USER = os.popen("echo ${SUDO_USER:-$(who -m | awk '{ print $1 }')}").readline().strip()
USER = os.popen("ls -l /opt/ |grep ezblock | awk '{print $3}'").readline().strip()
USER_HOME = os.popen(f'getent passwd {USER} | cut -d: -f 6').readline().strip()

def log(msg:str, location='Upgrade', end='\n', flush=True, timestamp=True, color=''):
    with open('/opt/ezblock/log','a+') as log_file:
        if timestamp == True:
            _time = time.strftime("%y/%m/%d %H:%M:%S", time.localtime())
            ct = time.time()
            _msecs = '%03d '%((ct - int(ct)) * 1000)
            print('%s,%s[%s] %s'%(_time, _msecs, location, msg), end=end, flush=flush, file=log_file)
            print('\033[%sm%s,%s[%s] %s\033[0m'%(color, _time, _msecs, location, msg), end=end, flush=flush, file=sys.stdout)
        else:
            print('%s'%msg, end=end, flush=flush, file=log_file)
            print('\033[%sm%s\033[0m'%(color, msg), end=end, flush=flush, file=sys.stdout)


def run_command(cmd):
    import subprocess
    p = subprocess.Popen(
        cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    result = p.stdout.read().decode('utf-8')
    status = p.poll()
    return status, result

errors = []
def do(msg="", cmd=""):
    log("- %s ... " % (msg), end='')
    status, result = run_command(cmd)
    if status == 0 or status == None or result == "":
        log(msg='Done',timestamp=False)
    else:   
        log(msg='Error',timestamp=False, color='31')
        errors.append("%s error:\n  Status:%s\n  Error:%s" %
                      (msg, status, result))


def update():
    log(f'Upgrading to version {VERSION} ...')
    
    import requests
    git_url = None
    github_url = 'https://github.com/ezblockcode/ezb-pi'
    gitee_url = 'https://gitee.com/sunfounder/ezb-pi'

    do(msg='set git timeoout',
        cmd='git config --global http.lowSpeedLimit 2000'
        + ' && git config --global http.lowSpeedTime 10 '
    )

    log('- github access testing ...', end=' ')
    for _ in range(3):
        try:
            if requests.get(github_url, timeout=5).status_code == 200:
                git_url = github_url
                log('pass', timestamp=False, color='32')
                break
        except:
            pass
    else:
        log('fail', timestamp=False, color='33')
        git_url = None


    if git_url is None:
        log('- gitee access testing ...', end=' ')
        for _ in range(3):
            try:
                if requests.get(gitee_url, timeout=5).status_code == 200:
                    git_url = gitee_url
                    log('pass', timestamp=False, color='32')
                    break
            except:
                pass
        else:
            log('fail', timestamp=False, color='33')
            log('Can\'t access github or gitee, please try again.')
            sys.exit(1) # failed


    os.chdir(f"{USER_HOME}/ezb-pi/")
    do(msg=f'git remote set-url origin {git_url}',
        cmd=f'git remote set-url origin {git_url}')

    _ , result = run_command(f"git tag | grep {VERSION}")
    if result != '':
        do(msg=f'git tag -d {VERSION}',
            cmd=f'git tag -d {VERSION}')  
    
    do(msg='git fetch',
        cmd='git fetch')

    do(msg=f'git checkout -f {VERSION}',
        cmd=f'git checkout -f {VERSION}')

    do(msg=f'install {VERSION}',
        cmd='sudo python3 install.py --no-dep')

    if len(errors) == 0:
        log("Finished.")
        sys.exit(0) # success
    else:
        log('Error happened in install process:', color='31')
        for error in errors:
            log(error, timestamp=False, color='31')
        log("Try to fix it yourself, or contact service@sunfounder.com with this message\n")
        sys.exit(1) # failed


if __name__ == "__main__":
    try:
       update() 
    except KeyboardInterrupt:
        log(" ", timestamp=False)
        log("Canceled.")

